<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['sturecmsaid']==0)) {
  header('location:logout.php');
  } else{
   if(isset($_POST['submit']))
  {
 $stname=$_POST['stname'];
 $stemail=$_POST['stemail'];
 $stdept=$_POST['stdept'];
 $gender=$_POST['gender'];
 $dob=$_POST['dob'];
 $stid=$_POST['stid'];
 $ph=$_POST['ph'];
 $uname=$_POST['uname'];
 $pswd=md5($_POST['pswd']);
 $ret="select UserName from student where UserName=:uname || StID=:stid";
 $query= $dbh -> prepare($ret);
$query->bindParam(':uname',$uname,PDO::PARAM_STR);
$query->bindParam(':stid',$stid,PDO::PARAM_STR);
$query-> execute();
     $results = $query -> fetchAll(PDO::FETCH_OBJ);
if($query -> rowCount() == 0)
{
$extension = substr($image,strlen($image)-4,strlen($image));
$allowed_extensions = array(".jpg","jpeg",".png",".gif");
if(!in_array($extension,$allowed_extensions))
{
echo "<script>alert('Logo has Invalid format. Only jpg / jpeg/ png /gif format allowed');</script>";
}
else
{
$image=md5($image).time().$extension;
 move_uploaded_file($_FILES["image"]["tmp_name"],"images/".$image);
$sql="insert into student(StudentName,StudentEmail,Department,Gender,DOB,StID,Phone,UserName,Pswd)values(:stname,:stemail,:stdept,:gender,:dob,:stid,:ph,:uname,:pswd)";
$query=$dbh->prepare($sql);
$query->bindParam(':stname',$stname,PDO::PARAM_STR);
$query->bindParam(':stemail',$stemail,PDO::PARAM_STR);
$query->bindParam(':stdept',$stdept,PDO::PARAM_STR);
$query->bindParam(':gender',$gender,PDO::PARAM_STR);
$query->bindParam(':dob',$dob,PDO::PARAM_STR);
$query->bindParam(':stid',$stid,PDO::PARAM_STR);
$query->bindParam(':ph',$ph,PDO::PARAM_STR);
$query->bindParam(':uname',$uname,PDO::PARAM_STR);
$query->bindParam(':pswd',$pswd,PDO::PARAM_STR);

 $query->execute();
   $LastInsertId=$dbh->lastInsertId();
   if ($LastInsertId>0) {
    echo '<script>alert("Student has been added.")</script>';
echo "<script>window.location.href ='newstudent.php'</script>";
  }
  else
    {
         echo '<script>alert("Something Went Wrong. Please try again")</script>';
    }
}}

else
{

echo "<script>alert('Student Id  already exists. Please try again');</script>";
}
}
  ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="sedit.css">
    <title>School Admin Dashboard</title>
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"/>
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"/>
    <link rel="stylesheet" href="vendors/select2/select2.min.css">
    <link rel="stylesheet" href="vendors/select2-bootstrap-theme/select2-bootstrap.min.css">
</head>
<body>

    <section id="m1">
        <div class="l">
            <img src="Images/logo.png" alt="">
            <h2>School Admin Dashboard</h2>
            
        </div>

        <div class="list">
            <li><a href="schooladmin.php">Dashboard</a></li>
            <li><a href="studentlist.php">Students </a></li>
            <li><a href="bowner.php">Buisness Owners</a></li>
            <li><a href="reports.php">Reports</a></li> 
        </div>
        
    </section>
    
    <section id="main">
        <div class="nav">
            <div class="a1">
                <div class="srch">
                    <i class="far fa-search"></i>
                    <input type="text" placeholder="Search" name="">
                </div>
            </div>

            <div class="pro">
                <a href="homepage.asp">Mercado Escolar Home</a>
                <img src="Images/img1.jpg" alt="">
            </div>
        </div>

        <h3 class="a2">Add New Students</h3>
    
        <dir class="b1">

            <div class="row">
          
              <div class="col-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    
                    <form class="forms-sample" method="post" enctype="multipart/form-data">
                      
                      <div class="form-group">
                        <label for="exampleInputName1">Student Name</label>
                        <input type="text" name="stname" value="" class="form-control" required='true'>
                      </div>
                      <div class="form-group">
                        <label for="exampleInputName1">Student Email</label>
                        <input type="text" name="stemail" value="" class="form-control" required='true'>
                      </div>
                      <div class="form-group">
                        <label for="exampleInputName1">Student Department</label>
                        <input type="text" name="stdept" value="" class="form-control" required='true'>
                      </div>
                      <div class="form-group">
                        <label for="exampleInputName1">Gender</label>
                        <select name="gender" value="" class="form-control" required='true'>
                          <option value="">Choose Gender</option>
                          <option value="Male">Male</option>
                          <option value="Female">Female</option>
                        </select>
                      </div>
                      <div class="form-group">
                        <label for="exampleInputName1">Date of Birth</label>
                        <input type="date" name="dob" value="" class="form-control" required='true'>
                      </div>
                     
                      <div class="form-group">
                        <label for="exampleInputName1">Student ID</label>
                        <input type="text" name="stid" value="" class="form-control" required='true'>
                      </div>
                      <div class="form-group">
                        <label for="exampleInputName1">Contact Number</label>
                        <input type="text" name="ph" value="" class="form-control" required='true' maxlength="10" pattern="[0-9]+">
                      </div>
                  
<h3>Login details</h3>
<div class="form-group">
                        <label for="exampleInputName1">User Name</label>
                        <input type="text" name="uname" value="" class="form-control" required='true'>
                      </div>
                      <div class="form-group">
                        <label for="exampleInputName1">Password</label>
                        <input type="Password" name="pswd" value="" class="form-control" required='true'>
                      </div>
                      <button type="submit" class="btn" name="submit">Add</button>
                     
                    </form>
                  </div>
                </div>
              </div>
            </div>
            
        </dir>
    </section>


</body>
</html>
<?php }  ?>





