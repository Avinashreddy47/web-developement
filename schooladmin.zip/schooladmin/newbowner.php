<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['sturecmsaid']==0)) {
  header('location:logout.php');
  } else{
   if(isset($_POST['submit']))
  {
 $bname=$_POST['bname'];
 $boname=$_POST['boname'];
 $email=$_POST['stemail'];
 $addr=$_POST['addr'];
 $bid=$_POST['stid'];
 $ph=$_POST['ph'];
 $uname=$_POST['uname'];
 $pswd=md5($_POST['pswd']);
 $ret="select UserName from bowner where UserName=:uname || BID=:bid";
 $query= $dbh -> prepare($ret);
$query->bindParam(':uname',$uname,PDO::PARAM_STR);
$query->bindParam(':bid',$bid,PDO::PARAM_STR);
$query-> execute();
     $results = $query -> fetchAll(PDO::FETCH_OBJ);
if($query -> rowCount() == 0)
{
$extension = substr($image,strlen($image)-4,strlen($image));
$allowed_extensions = array(".jpg","jpeg",".png",".gif");
if(!in_array($extension,$allowed_extensions))
{
echo "<script>alert('Logo has Invalid format. Only jpg / jpeg/ png /gif format allowed');</script>";
}
else
{
$image=md5($image).time().$extension;
 move_uploaded_file($_FILES["image"]["tmp_name"],"images/".$image);
$sql="insert into bowner(BusinessName,BusinessOwner,Email,BID,Phone,Address,UserName,Pswd)values(:bname,:boname,:email,:bid,:ph,:addr,:uname,:pswd)";
$query=$dbh->prepare($sql);
$query->bindParam(':bname',$bname,PDO::PARAM_STR);
$query->bindParam(':boname',$boname,PDO::PARAM_STR);
$query->bindParam(':email',$email,PDO::PARAM_STR);
$query->bindParam(':bid',$bid,PDO::PARAM_STR);
$query->bindParam(':ph',$ph,PDO::PARAM_STR);
$query->bindParam(':addr',$addr,PDO::PARAM_STR);
$query->bindParam(':uname',$uname,PDO::PARAM_STR);
$query->bindParam(':pswd',$pswd,PDO::PARAM_STR);

 $query->execute();
   $LastInsertId=$dbh->lastInsertId();
   if ($LastInsertId>0) {
    echo '<script>alert("Business Owner has been added.")</script>';
echo "<script>window.location.href ='newbowner.php'</script>";
  }
  else
    {
         echo '<script>alert("Something Went Wrong. Please try again")</script>';
    }
}}

else
{

echo "<script>alert('Student Id  already exists. Please try again');</script>";
}
}
  ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bedit.css">
    <title>School Admin Dashboard</title>
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"/>
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"/>
    <link rel="stylesheet" href="vendors/select2/select2.min.css">
    <link rel="stylesheet" href="vendors/select2-bootstrap-theme/select2-bootstrap.min.css">
</head>
<body>

    <section id="m1">
        <div class="l">
            <img src="Images/logo.png" alt="">
            <h2>School Admin Dashboard</h2>
            
        </div>

        <div class="list">
            <li><a href="schooladmin.php">Dashboard</a></li>
            <li><a href="studentlist.php">Students </a></li>
            <li><a href="bowner.php">Buisness Owners</a></li>
            <li><a href="reports.php">Reports</a></li> 
        </div>
        
    </section>
    
    <section id="main">
        <div class="nav">
            <div class="a1">
                <div class="srch">
                    <i class="far fa-search"></i>
                    <input type="text" placeholder="Search" name="">
                </div>
            </div>

            <div class="pro">
                <a href="homepage.asp">Mercado Escolar Home</a>
                <img src="Images/img1.jpg" alt="">
            </div>
        </div>

        <h3 class="a2">Add New Business Owners</h3>
    
        <dir class="b1">

            <div class="row">
          
              <div class="col-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    
                   
                    <form class="forms-sample" method="post" enctype="multipart/form-data">
                      
                      <div class="form-group">
                        <label for="exampleInputName1">Business Name</label>
                        <input type="text" name="bname" value="" class="form-control" required='true'>
                      </div>
                      <div class="form-group">
                        <label for="exampleInputName1">Business Owner</label>
                        <input type="text" name="boname" value="" class="form-control" required='true'>
                      </div>
                      <div class="form-group">
                        <label for="exampleInputName1">Email</label>
                        <input type="text" name="email" value="" class="form-control" required='true'>
                      </div>
                      <div class="form-group">
                        <label for="exampleInputName1">Business ID</label>
                        <input type="text" name="bid" value="" class="form-control" required='true'>
                      </div>
                      <div class="form-group">
                        <label for="exampleInputName1">Contact Number</label>
                        <input type="text" name="ph" value="" class="form-control" required='true' maxlength="10" pattern="[0-9]+">
                      </div>
                      <div class="form-group">
                        <label for="exampleInputName1">Address</label>
                        <textarea name="addr" class="form-control" required='true'></textarea>
                      </div>
                  
<h3>Login details</h3>
<div class="form-group">
                        <label for="exampleInputName1">User Name</label>
                        <input type="text" name="uname" value="" class="form-control" required='true'>
                      </div>
                      <div class="form-group">
                        <label for="exampleInputName1">Password</label>
                        <input type="Password" name="pswd" value="" class="form-control" required='true'>
                      </div>
                      <button type="submit" class="btn" name="submit">Add</button>
                     
                    </form>
                  </div>
                </div>
              </div>
            </div>
            
        </dir>
    </section>


</body>
</html>
<?php }  ?>





