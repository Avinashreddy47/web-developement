<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['sturecmsaid']==0)) {
  header('location:logout.php');
  } 
else{
   if(isset($_POST['submit']))
  {
 $bname=$_POST['bname'];
 $boname=$_POST['boname'];
 $email=$_POST['email'];
 $bid=$_POST['bid'];
 $ph=$_POST['ph'];
 $addr=$_POST['addr'];
 $eid=$_GET['editid'];
$sql="update bowner set BusinessName=:bname,BusinessOwner=:boname,Email=:email,BID=:bid,Phone=:ph,Address=:addr where ID=:eid";
$query=$dbh->prepare($sql);
$query->bindParam(':bname',$bname,PDO::PARAM_STR);
$query->bindParam(':boname',$boname,PDO::PARAM_STR);
$query->bindParam(':email',$email,PDO::PARAM_STR);
$query->bindParam(':bid',$bid,PDO::PARAM_STR);
$query->bindParam(':ph',$ph,PDO::PARAM_STR);
$query->bindParam(':addr',$addr,PDO::PARAM_STR);
$query->bindParam(':eid',$eid,PDO::PARAM_STR);
 $query->execute();
  echo '<script>alert("Business Details successfully updated")</script>';
}

  ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bedit.css">
    <title>School Admin Dashboard</title>
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"/>
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"/>
    <link rel="stylesheet" href="vendors/select2/select2.min.css">
    <link rel="stylesheet" href="vendors/select2-bootstrap-theme/select2-bootstrap.min.css">
    <link rel="stylesheet" href="vendors/simple-line-icons/css/simple-line-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/css/vendor.bundle.base.css">
</head>
<body>

    <section id="m1">
        <div class="l">
            <img src="Images/logo.png" alt="">
            <h2>School Admin Dashboard</h2>
            
        </div>

        <div class="list">
            <li><a href="schooladmin.php">Dashboard</a></li>
            <li><a href="studentlist.php">Students </a></li>
            <li><a href="bowner.php">Buisness Owners</a></li>
            <li><a href="reports.php">Reports</a></li> 
        </div>
        
    </section>
    
    <section id="main">
        <div class="nav">
            <div class="a1">
                <div class="srch">
                    <i class="far fa-search"></i>
                    <input type="text" placeholder="Search" name="">
                </div>
            </div>

            <div class="pro">
                <a href="homepage.asp">Mercado Escolar Home</a>
                <img src="Images/img1.jpg" alt="">
            </div>
        </div>

        <h3 class="a2">Edit Business Details</h3>
    
        <dir class="b1">

          <div class="row">
          
              <div class="col-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    
                   
                    <form class="forms-sample" method="post" enctype="multipart/form-data">
                      <?php
$eid=$_GET['editid'];
$sql="SELECT bowner.BusinessName,bowner.BusinessOwner,bowner.Email,bowner.BID,bowner.Phone,bowner.Address,bowner.UserName,bowner.Pswd from bowner where bowner.ID=:eid";
$query = $dbh -> prepare($sql);
$query->bindParam(':eid',$eid,PDO::PARAM_STR);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $row)
{               ?>
                      <div class="form-group">
                        <label for="exampleInputName1">Business Name</label>
                        <input type="text" name="bname" value="<?php  echo htmlentities($row->BusinessName);?>" class="form-control" required='true'>
                      </div>
                      <div class="form-group">
                        <label for="exampleInputName1">Business Owner</label>
                        <input type="text" name="boname" value="<?php  echo htmlentities($row->BusinessOwner);?>" class="form-control" required='true'>
                      </div>
                      <div class="form-group">
                        <label for="exampleInputName1">Email</label>
                        <input type="text" name="email" value="<?php  echo htmlentities($row->Email);?>" class="form-control" required='true'>
                      </div>
                      <div class="form-group">
                        <label for="exampleInputName1">Business ID</label>
                        <input type="text" name="bid" value="<?php  echo htmlentities($row->BID);?>" class="form-control" readonly='true'>
                      </div>
                      <div class="form-group">
                        <label for="exampleInputName1">Contact Number</label>
                        <input type="text" name="ph" value="<?php  echo htmlentities($row->Phone);?>" class="form-control" required='true' maxlength="10" pattern="[0-9]+">
                      </div>
                      <div class="form-group">
                        <label for="exampleInputName1">Address</label>
                        <textarea name="addr" value="<?php  echo htmlentities($row->Address);?>" class="form-control" required='true'></textarea>
                      </div>
<h3>Login Details</h3>
<div class="form-group">
                        <label for="exampleInputName1">User Name</label>
                        <input type="text" name="uname" value="<?php  echo htmlentities($row->UserName);?>" class="form-control" readonly='true'>
                      </div>
                      <div class="form-group">
                        <label for="exampleInputName1">Password</label>
                        <input type="Password" name="password" value="<?php  echo htmlentities($row->Pswd);?>" class="form-control" readonly='true'>
                      </div><?php $cnt=$cnt+1;}} ?>
                      <button type="submit" class="btn" name="submit">Update</button>
                     
                    </form>
                  </div>
                </div>
              </div>
            </div>

            
        </dir>
    </section>

<script src="vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <script src="vendors/select2/select2.min.js"></script>
    <script src="vendors/typeahead.js/typeahead.bundle.min.js"></script>

</body>
</html>
<?php }  ?>