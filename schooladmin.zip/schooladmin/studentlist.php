<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['sturecmsaid']==0)) {
  header('location:logout.php');
  } else{
   // Code for deletion
if(isset($_GET['delid']))
{
$rid=intval($_GET['delid']);
$sql="delete from student where ID=:rid";
$query=$dbh->prepare($sql);
$query->bindParam(':rid',$rid,PDO::PARAM_STR);
$query->execute();
 echo "<script>alert('Data deleted');</script>"; 
  echo "<script>window.location.href = 'studentlist.php'</script>";     


}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="studentlist.css">
    <title>School Admin Dashboard</title>
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"/>
</head>
<body>

    <section id="m1">
        <div class="l">
            <img src="Images/logo.png" alt="">
            <h2>School Admin Dashboard</h2>
            
        </div>

        <div class="list">
            <li><a href="schooladmin.php">Dashboard</a></li>
            <li><a href="studentlist.php">Students </a></li>
            <li><a href="bowner.php">Buisness Owners</a></li>
            <li><a href="reports.php">Reports</a></li> 
        </div>
        
    </section>
    
    <section id="main">
        <div class="nav">
            <div class="a1">
                <div class="srch">
                    <i class="far fa-search"></i>
                    <input type="text" placeholder="Search" name="">
                </div>
            </div>

            <div class="pro">
                <a href="homepage.asp">Mercado Escolar Home</a>
                <img src="Images/img1.jpg" alt="">
            </div>
        </div>

        <h3 class="a2">List of Students</h3>
        <p class="a3"><a href="newstudent.php">Add New Student</a></p>
        

        <dir class="b1">
            <table width="100%">
                <thead>
                    <tr>
                        <td>Full Name</td>
                        <td>Email/Phone</td>
                        <td>Department</td>
                        <td>DOB</td>
                        <td></td>
                        <td></td>
                    </tr>
                </thead>
                <tbody>

                    <?php
                            if (isset($_GET['pageno'])) {
            $pageno = $_GET['pageno'];
        } else {
            $pageno = 1;
        }
        // Formula for pagination
        $no_of_records_per_page = 15;
        $offset = ($pageno-1) * $no_of_records_per_page;
       $ret = "SELECT ID FROM student";
$query1 = $dbh -> prepare($ret);
$query1->execute();
$results1=$query1->fetchAll(PDO::FETCH_OBJ);
$total_rows=$query1->rowCount();
$total_pages = ceil($total_rows / $no_of_records_per_page);
$sql="SELECT student.StID,student.ID as sid,student.StudentName,student.StudentEmail,student.DOB,student.Department,student.Phone from student LIMIT $offset, $no_of_records_per_page";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);

$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $row)
{               ?>   

                    <tr>
                        <td class="n1">
                            <img src="Images/img1.png" alt="">
                            <div class="n2">
                                <h5><?php  echo htmlentities($row->StudentName);?></h5>
                                <p><?php  echo htmlentities($row->StID);?></p>
                            </div>
                        </td>
                        
                        <td class="n3">
                             <h5><?php  echo htmlentities($row->StudentEmail);?></h5>
                             <p><?php  echo htmlentities($row->Phone);?></p>
                        </td>
                        <td class="n4">
                            <h5><?php  echo htmlentities($row->Department);?></h5>
                        </td>
                        <td class="n5">
                            <p><?php  echo htmlentities($row->DOB);?> </p>
                        </td>
                        <td class="n6"><a href="editst.php?editid=<?php echo htmlentities ($row->sid);?>">Edit</i></a></td>
                        <td class="n6"><a href="studentlist.php?delid=<?php echo ($row->sid);?>" onclick="return confirm('Do you really want to Delete ?');">Delete </a>
                        </td> 
                    </tr>
                    <?php $cnt=$cnt+1;}} ?>
                
                </tbody>
            </table>
        </dir>
    </section>


</body>
</html>
<?php }  ?>




